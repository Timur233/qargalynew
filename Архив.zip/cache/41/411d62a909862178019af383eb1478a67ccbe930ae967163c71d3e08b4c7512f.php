<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/main_callback.twig */
class __TwigTemplate_6eaba3e78e46cec11c4ae9468df62fef473fc31ffcff9078d1627c991cba0a05 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section 
   id=\"callback\" 
   class=\"callback-h section section--primary\"
   ref=\"mainCallback\"
>
   <img 
       class=\"section__paralax section__paralax--primary\" 
       src=\"https://cms.abpx.kz/storage/uploads/2022/10/19/634fda74b60e6order-img-3.svg\"
       :style=\"{transform: paralaxEffect?.paralax?.main_callback}\"
   >
   <img 
       class=\"section__paralax section__paralax--second\" 
       src=\"https://cms.abpx.kz/storage/uploads/2022/10/20/63512b3579128order-img-1.svg\"
       :style=\"{transform: paralaxEffect?.paralax?.main_callback_two}\"
   >
   <img 
       class=\"section__paralax callback-h__paralax\" 
       src=\"https://cms.abpx.kz/storage/uploads/2022/11/08/636a4d8826e56order-img-2.svg\"
       :style=\"{transform: paralaxEffect?.paralax?.main_callback_three}\"
   >
   <div class=\"container\">
      <div class=\"section__title-block callback-h__title-block\">
         <h2 class=\"section__title section__title--gold\">
            ";
        // line 24
        echo (($__internal_compile_0 = ($context["translate"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["callback_form_title"] ?? null) : null);
        echo "
         </h2>
      </div>
      <div class=\"flex\">
         <div class=\"flex__8 callback-container\">
            <callback-form class=\"callback-h__form\"
               user-name-placeholder=\"";
        // line 30
        echo twig_escape_filter($this->env, (($__internal_compile_1 = ($context["translate"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["name"] ?? null) : null), "html", null, true);
        echo "\"
               no-valid-phone-number=\"";
        // line 31
        echo twig_escape_filter($this->env, (($__internal_compile_2 = ($context["translate"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["no_valid_number"] ?? null) : null), "html", null, true);
        echo "\"
               no-valid-form-data=\"";
        // line 32
        echo twig_escape_filter($this->env, (($__internal_compile_3 = ($context["translate"] ?? null)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3["na_valid_form"] ?? null) : null), "html", null, true);
        echo "\"
               submit-text=\"";
        // line 33
        echo twig_escape_filter($this->env, (($__internal_compile_4 = ($context["translate"] ?? null)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4["leave_order"] ?? null) : null), "html", null, true);
        echo "\"
               @show-form-result=\"callbackResultShow = true\"
            ></callback-form>
         </div>
      </div>
   </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/main_callback.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 33,  79 => 32,  75 => 31,  71 => 30,  62 => 24,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/main_callback.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/main_callback.twig");
    }
}
