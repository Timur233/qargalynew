<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/slider.twig */
class __TwigTemplate_441041c46b336091de425aaedd8f935802b4e1214d81efc04da4d23404d1aadc extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"home\" data-anchor=\"home\" class=\"main-slider\" ref=\"sliderSection\">
    
    <div class=\"main-slider__swiper swiper-container\">
        <div class=\"swiper-wrapper main-slider__wrapper\">
            <div 
                class=\"swiper-slide main-slider__slide\" 
            >
                <div class=\"main-slider__image\" :style=\"{transform: paralaxEffect?.paralax?.slider}\">
                    <img src=\"https://cms.abpx.kz";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["slider_image"] ?? null), "path", [], "any", false, false, false, 9), "html", null, true);
        echo "\">
                </div>
                <div class=\"main-slider__content\">
                    <div class=\"slider-promo\">
                        <div class=\"slider-promo__developer promo-developer\">
                            <span class=\"promo-developer__label\">";
        // line 14
        echo (($__internal_compile_0 = ($context["translate"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["developer"] ?? null) : null);
        echo "</span>
                            <img 
                                src=\"https://cms.abpx.kz/storage/uploads/2022/02/09/620411381e38861c9645a93a2blogo-bold-1.svg\" 
                                class=\"promo-developer__logo\"
                            >
                            <a href=\"https://exin.kz/\" target=\"_blank\" class=\"promo-developer__link\">
                                exin.kz
                            </a>
                        </div>
                        <div class=\"slider-promo__info promo-info\">
                            <div class=\"promo-info__price promo-price\">
                                <h3 class=\"promo-price__title\">
                                    ";
        // line 26
        if ((($context["lang"] ?? null) == "kk")) {
            // line 27
            echo "                                        ";
            echo twig_escape_filter($this->env, ($context["slider_price"] ?? null), "html", null, true);
            echo " бастап тг/м<sup>2</sup>
                                    ";
        } else {
            // line 29
            echo "                                        от ";
            echo twig_escape_filter($this->env, ($context["slider_price"] ?? null), "html", null, true);
            echo " тг/м<sup>2</sup>
                                    ";
        }
        // line 31
        echo "                                </h3>
                            </div>
                            <div class=\"promo-info__contribution promo-contribution\">
                                <span class=\"promo-contribution__label\">
                                    ";
        // line 35
        echo (($__internal_compile_1 = ($context["translate"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["payment_from"] ?? null) : null);
        echo "
                                </span>
                                <span class=\"promo-contribution__value\">
                                    ";
        // line 38
        echo twig_escape_filter($this->env, ($context["slider_contribution"] ?? null), "html", null, true);
        echo "
                                </span>
                            </div>
                            <div class=\"promo-info__links promo-links\">

                                <div 
                                    class=\"section__paralax promo-links__paralax\" 
                                    style=\"background-image: url(https://cms.abpx.kz/storage/uploads/2022/10/20/63512b3579128order-img-1.svg);\"
                                ></div>

                                <span class=\"promo-links__label\">
                                    ";
        // line 49
        echo (($__internal_compile_2 = ($context["translate"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["new_area"] ?? null) : null);
        echo "
                                </span>
                                <a href=\"#contacts\" class=\"promo-links__adress\">
                                    ";
        // line 52
        echo ($context["site_adress"] ?? null);
        echo "
                                </a>
                                <a href=\"#appartaments\" class=\"promo-links__desctop-btn btn btn--outline btn--white\">
                                    ";
        // line 55
        echo twig_escape_filter($this->env, (($__internal_compile_3 = ($context["translate"] ?? null)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3["select_flat"] ?? null) : null), "html", null, true);
        echo "
                                </a>
                                <a href=\"#appartaments\" class=\"promo-links__mobile-btn btn btn--gradient\">
                                    ";
        // line 58
        echo twig_escape_filter($this->env, (($__internal_compile_4 = ($context["translate"] ?? null)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4["select_flat"] ?? null) : null), "html", null, true);
        echo "
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <a href=\"#contacts\" class=\"main-slider__adress\">
                    ";
        // line 65
        echo ($context["site_adress"] ?? null);
        echo "
                </a>
            </div>
        </div>
    </div>
    
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/slider.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 65,  128 => 58,  122 => 55,  116 => 52,  110 => 49,  96 => 38,  90 => 35,  84 => 31,  78 => 29,  72 => 27,  70 => 26,  55 => 14,  47 => 9,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/slider.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/slider.twig");
    }
}
