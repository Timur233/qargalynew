<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/online_tour.twig */
class __TwigTemplate_6892c6912c2325bed22e37e3f4b4d5c9ceadb9461001dea9ce1419fe7e08fd25 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if (($context["online_tour"] ?? null)) {
            // line 2
            echo "    <section class=\"section section--pb online-tour\">
        <div class=\"container\">
            <div class=\"section__title-block\">
                <h2 class=\"section__title\">";
            // line 5
            echo twig_escape_filter($this->env, ($context["online_tour_title"] ?? null), "html", null, true);
            echo "</h2>
            </div>
        </div>

        <div class=\"container\">
            <iframe 
                width=\"100%\"
                id=\"embed-id\" 
                loading=\"lazy\" 
                class=\"ku-embed online-tour__frame\" 
                frameborder=\"0\" 
                allowfullscreen=\"\" 
                allow=\"xr-spatial-tracking; gyroscope; accelerometer\" 
                scrolling=\"no\" 
                src=\"";
            // line 19
            echo twig_escape_filter($this->env, ($context["online_tour_link"] ?? null), "html", null, true);
            echo "\" 
                style=\"height: 700px;\"
            ></iframe>
        </div>
    </section>
";
        }
    }

    public function getTemplateName()
    {
        return "widgets/online_tour.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 19,  44 => 5,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/online_tour.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/online_tour.twig");
    }
}
