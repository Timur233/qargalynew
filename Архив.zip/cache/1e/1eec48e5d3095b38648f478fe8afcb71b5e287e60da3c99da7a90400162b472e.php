<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/discounts.twig */
class __TwigTemplate_492f5aa564180ae73755920d4987d1fb55ca95a29d7cd657cc35f5dc14ca1b83 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if (($context["discount_enable"] ?? null)) {
            // line 2
            echo "    <section class=\"section discounts\">
        <div class=\"container\">
            ";
            // line 4
            if (($context["discount_title"] ?? null)) {
                // line 5
                echo "                <div class=\"section__title-block\">
                    <h2 class=\"section__title\">";
                // line 6
                echo twig_escape_filter($this->env, ($context["discount_title"] ?? null), "html", null, true);
                echo "</h2>
                </div>
            ";
            }
            // line 9
            echo "            <discount-swiper>
                ";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["discount_items"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 11
                echo "                    <swiper-slide>
                        <picture>
                            <source 
                                media=\"(max-width: 550px)\" 
                                srcset=\"https://cms.abpx.kz";
                // line 15
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_0 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 15)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0[1] ?? null) : null), "settings", [], "any", false, false, false, 15), "image", [], "any", false, false, false, 15), "path", [], "any", false, false, false, 15), "html", null, true);
                echo "\">
                            <img 
                                src=\"https://cms.abpx.kz";
                // line 17
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_1 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 17)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1[0] ?? null) : null), "settings", [], "any", false, false, false, 17), "image", [], "any", false, false, false, 17), "path", [], "any", false, false, false, 17), "html", null, true);
                echo "\" 
                                class=\"swiper-lazy discounts__image\"
                                @click=\"callbackModalShow = !callbackModalShow\"
                            >
                        </picture>
                        <div class=\"swiper-lazy-preloader\"></div>
                    </swiper-slide>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 25
            echo "            </discount-swiper>
        </div>
    </section>
";
        }
    }

    public function getTemplateName()
    {
        return "widgets/discounts.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 25,  72 => 17,  67 => 15,  61 => 11,  57 => 10,  54 => 9,  48 => 6,  45 => 5,  43 => 4,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/discounts.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/discounts.twig");
    }
}
