<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/banners.twig */
class __TwigTemplate_8122a8fb37a00eb032b537b41b5c7d7707de0e1811cbb45a4dbeeb995061f7e9 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if (($context["banners"] ?? null)) {
            // line 2
            echo "    <section class=\"section banners\">
        <div class=\"container\">
            ";
            // line 4
            if (($context["banners_title"] ?? null)) {
                // line 5
                echo "                <div class=\"section__title-block\">
                    <h2 class=\"section__title\">";
                // line 6
                echo twig_escape_filter($this->env, ($context["banners_title"] ?? null), "html", null, true);
                echo "</h2>
                </div>
            ";
            }
            // line 9
            echo "            <div class=\"flex banners__list\">
                ";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["banners_list"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["banner"]) {
                // line 11
                echo "                    <div class=\"banners__item ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["banner"], "settings", [], "any", false, false, false, 11), "class", [], "any", false, false, false, 11), "html", null, true);
                echo "\">
                        <img 
                            src=\"https://cms.abpx.kz";
                // line 13
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_0 = twig_get_attribute($this->env, $this->source, $context["banner"], "children", [], "any", false, false, false, 13)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0[0] ?? null) : null), "settings", [], "any", false, false, false, 13), "image", [], "any", false, false, false, 13), "path", [], "any", false, false, false, 13), "html", null, true);
                echo "\" 
                            class=\"banners__image\"
                        >
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['banner'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 18
            echo "            </div>
        </div>
    </section>
";
        }
    }

    public function getTemplateName()
    {
        return "widgets/banners.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 18,  67 => 13,  61 => 11,  57 => 10,  54 => 9,  48 => 6,  45 => 5,  43 => 4,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/banners.twig", "/Applications/XAMPP/xamppfiles/htdocs/altyncity/app/views/widgets/banners.twig");
    }
}
