<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/about_developer.twig */
class __TwigTemplate_58f9fc75ec23109097d6e202f46efcd6b15297c8b9366fae82381c340bd6a5c7 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"about-developer\" class=\"about-developer section\">
    <div class=\"container\">
        <div class=\"section-title about-developer__title\">
            <h2 class=\"section-title__h2\">
                <strong>О exclusive </strong>
                qurylys
            </h2>
        </div>
        <div class=\"about-developer__block\">
            <div class=\"flex\">
                <div class=\"flex__9 about-developer__info\">
                    <p>Exclusive Qurylys — это многопрофильная структура республиканского уровня, масштаб бизнеса которой выходит за рамки исключительно девелоперской деятельности.</p>
                    <p>За 15 лет существования наша компания зарекомендовала себя как надежный партнер, способный оперативно решать все вопросы по строительству и реконструкции объектов.</p>
                    <p>Компания обеспечивает полный цикл работ – от разработки концепции застройки и строительства до сдачи объектов с последующей эксплуатацией. Социальные и коммерческие проекты от Exclusive Qurylys полностью обеспечены социальной инфраструктурой и отвечают всем потребностям современного городского жителя.</p>
                </div>
                <div class=\"flex__3 about-developer__items\">
                    <div class=\"about-developer__logos\">
                        <a href=\"#\">
                            <img src=\"assets/img/dark-logo.svg\" alt=\"\">
                        </a>
                        <a href=\"#\">
                            <img src=\"assets/img/exin-logo.svg\" alt=\"\">
                        </a>
                    </div>
                    <a href=\"https://exin.kz/\" target=\"_blank\" class=\"btn btn--black\">
                        Узнать подробнее
                    </a>
                </div>
            </div>
        </div>
        <div class=\"about-developer__adv about-adv\">
            <div class=\"about-adv__item\">
                <div class=\"about-adv__number\">
                    17
                </div>
                <div class=\"about-adv__info-block\">
                    <h3 class=\"about-adv__title\">
                        ЖИЛЫХ<br>КОМПЛЕКСОВ
                    </h3>
                    <div class=\"about-adv__text\">
                        <p>
                            Exclusive Qurylys – это высококвалифицированный персонал управленцев и инженерно-технического состава, усиленная база материально-технического снабжения, наличие допусков ко всем видам строительно-монтажных, отделочных и инженерных работ.
                        </p>
                    </div>
                </div>
            </div>
            <div class=\"about-adv__item\">
                <div class=\"about-adv__number\">
                    15
                </div>
                <div class=\"about-adv__info-block\">
                    <h3 class=\"about-adv__title\">
                        ЛЕТ НА<br>РЫНКЕ
                    </h3>
                    <div class=\"about-adv__text\">
                        <p>
                            Exclusive Exclusive Qurylys – это 550 000 м² построенных жилых, коммерческих и торговых помещений, 850 000 м² строящихся к 2021-2022 году проектов. Опыт строительно-монтажных и отделочных работ, установки инженерного оборудования, внутренних инженерных сетей и лифтов, благоустройства прилегающей площади.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class=\"lines\">
        <div class=\"lines__wrapper container\">
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--3\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/about_developer.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/about_developer.twig", "/Applications/XAMPP/xamppfiles/htdocs/altyncity/app/views/widgets/about_developer.twig");
    }
}
