<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/horisontal_callback.twig */
class __TwigTemplate_d22b0c14fd7880500f9b8f702dca5b9bc226f7b51b2de768a7f042d153527dd6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section 
   id=\"callback\" 
   class=\"callback-h section section--primary\"
   ref=\"mainCallback\"
>
   <img 
       class=\"section__paralax section__paralax--primary\" 
       src=\"https://cms.abpx.kz/storage/uploads/2022/10/19/634fda74b60e6order-img-3.svg\"
       :style=\"{transform: paralaxEffect?.paralax?.main_callback}\"
   >
   <img 
       class=\"section__paralax section__paralax--second\" 
       src=\"https://cms.abpx.kz/storage/uploads/2022/10/20/63512b3579128order-img-1.svg\"
       :style=\"{transform: paralaxEffect?.paralax?.main_callback_two}\"
   >
   <img 
       class=\"section__paralax callback-h__paralax\" 
       src=\"https://cms.abpx.kz/storage/uploads/2022/11/08/636a4d8826e56order-img-2.svg\"
       :style=\"{transform: paralaxEffect?.paralax?.main_callback_three}\"
   >
   <div class=\"container\">
      <div class=\"section__title-block callback-h__title-block\">
         <h2 class=\"section__title section__title--gold\">
            Оставьте заявку и наш менеджер<br> 
            обязательно с вами свяжется
         </h2>
      </div>
      <div class=\"flex\">
         <div class=\"flex__8\">
            <callback-form class=\"callback-h__form\"
               :user-name-placeholder=\"'Имя'\"
               :no-valid-phone-number=\"'Пожалуйста, проверьте, правильность введённого вами номера!'\"
               :no-valid-form-data=\"'Не заполнены обязательные поля'\"
               :submit-text=\"'Отправить заявку'\"
            ></callback-form>
         </div>
      </div>
   </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/horisontal_callback.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/horisontal_callback.twig", "/Applications/XAMPP/xamppfiles/htdocs/altyncity/app/views/widgets/horisontal_callback.twig");
    }
}
