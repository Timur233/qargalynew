<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.twig */
class __TwigTemplate_ee8738a911f628187509bd57e39d8211fd560362fff3b744cb1930fb0bd35003 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<html lang=\"ru\">
  <head>
    <meta charset=\"UTF-8\" />
    <!--meta name=\"viewport\" content=\"width=1650, initial-scale=0, maximum-scale=5.0, user-scalable=1\" /-->
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />

    <title>";
        // line 7
        echo twig_escape_filter($this->env, ($context["site_title"] ?? null), "html", null, true);
        echo "</title>
    <link rel=\"shortcut icon\" href=\"https://cms.abpx.kz/";
        // line 8
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["site_favicon"] ?? null), "path", [], "any", false, false, false, 8), "html", null, true);
        echo "\" type=\"image/png\">
    <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/css/app.min.css?v=8\">

    ";
        // line 11
        echo ($context["site_scripts_in_head"] ?? null);
        echo "
  
  </head>
  <body>
  
    ";
        // line 16
        echo ($context["site_scripts_in_body"] ?? null);
        echo "

    <div id=\"app\">

      <fs-lightbox
        :toggler=\"isLightbox\"
        :sources=\"sourcesLightbox\"
        :disableLocalStorage=\"true\"
        :loadOnlyCurrentSource=\"true\"
        :exitFullscreenOnClose=\"true\"
        :slide=\"1\"
        :key=\"lightboxKey\"
      ></fs-lightbox>

      <fs-lightbox
        :toggler=\"isBuildingStepBox\"
        :sources=\"buildingStepSource\"
        :disableLocalStorage=\"true\"
        :loadOnlyCurrentSource=\"true\"
        :exitFullscreenOnClose=\"true\"
        :slide=\"1\"
        :key=\"lightboxKey + 1\"
      ></fs-lightbox>
  
      ";
        // line 40
        echo twig_include($this->env, $context, "widgets/_header.twig");
        echo "
  
      ";
        // line 42
        echo twig_include($this->env, $context, "widgets/slider.twig");
        echo "

      ";
        // line 44
        echo twig_include($this->env, $context, "widgets/discounts.twig");
        echo "

      ";
        // line 46
        echo twig_include($this->env, $context, "widgets/carousel.twig");
        echo "
  
      ";
        // line 48
        echo twig_include($this->env, $context, "widgets/pay_methods.twig");
        echo "

      ";
        // line 50
        echo twig_include($this->env, $context, "widgets/banners.twig");
        echo "

      ";
        // line 52
        echo twig_include($this->env, $context, "widgets/about_project.twig");
        echo "

      ";
        // line 54
        echo twig_include($this->env, $context, "widgets/benefits.twig");
        echo "

      ";
        // line 56
        echo twig_include($this->env, $context, "widgets/main_callback.twig");
        echo "

      ";
        // line 58
        echo twig_include($this->env, $context, "widgets/appartaments.twig");
        echo "

      ";
        // line 60
        echo twig_include($this->env, $context, "widgets/gallery.twig");
        echo "

      ";
        // line 62
        echo twig_include($this->env, $context, "widgets/online_tour.twig");
        echo "

      ";
        // line 64
        echo twig_include($this->env, $context, "widgets/commerce.twig");
        echo "

      ";
        // line 66
        echo twig_include($this->env, $context, "widgets/infrastructure.twig");
        echo "

      ";
        // line 68
        echo twig_include($this->env, $context, "widgets/building_steps.twig");
        echo "

      ";
        // line 70
        echo twig_include($this->env, $context, "widgets/callback.twig");
        echo "

      ";
        // line 72
        echo twig_include($this->env, $context, "widgets/about_company.twig");
        echo "

      ";
        // line 74
        echo twig_include($this->env, $context, "widgets/footer.twig");
        echo "

      ";
        // line 76
        echo twig_include($this->env, $context, "widgets/fixed_buttons.twig");
        echo "

      <modal :is-show=\"callbackModalShow\" @close-modal=\"callbackModalShow = false\">
        <form-modal
          :callback-form-title=\"'";
        // line 80
        echo (($__internal_compile_0 = ($context["translate"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["callback_form_title"] ?? null) : null);
        echo "'\"
          :user-name-placeholder=\"'";
        // line 81
        echo twig_escape_filter($this->env, (($__internal_compile_1 = ($context["translate"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["name"] ?? null) : null), "html", null, true);
        echo "'\"
          :no-valid-phone-number=\"'";
        // line 82
        echo twig_escape_filter($this->env, (($__internal_compile_2 = ($context["translate"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["no_valid_number"] ?? null) : null), "html", null, true);
        echo "'\"
          :no-valid-form-data=\"'";
        // line 83
        echo twig_escape_filter($this->env, (($__internal_compile_3 = ($context["translate"] ?? null)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3["no_valid_form"] ?? null) : null), "html", null, true);
        echo "'\"
          :submit-text=\"'";
        // line 84
        echo twig_escape_filter($this->env, (($__internal_compile_4 = ($context["translate"] ?? null)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4["send"] ?? null) : null), "html", null, true);
        echo "'\"
          @show-form-result=\"callbackResultShow = true\"
        >
          <div class=\"section__title-block callback-h__title-block\">
              <h2 class=\"section__title section__title--gold\">
                ";
        // line 89
        echo twig_escape_filter($this->env, (($__internal_compile_5 = ($context["translate"] ?? null)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess ? ($__internal_compile_5["thanks"] ?? null) : null), "html", null, true);
        echo "!<br>
                ";
        // line 90
        echo twig_escape_filter($this->env, (($__internal_compile_6 = ($context["translate"] ?? null)) && is_array($__internal_compile_6) || $__internal_compile_6 instanceof ArrayAccess ? ($__internal_compile_6["promise"] ?? null) : null), "html", null, true);
        echo "
              </h2>
          </div>
          <div class=\"flex\">
            <div class=\"flex__8\">
              <button 
                class=\"btn btn--gradient\" 
                @click=\"callbackModalShow = false\"
              >";
        // line 98
        echo twig_escape_filter($this->env, (($__internal_compile_7 = ($context["translate"] ?? null)) && is_array($__internal_compile_7) || $__internal_compile_7 instanceof ArrayAccess ? ($__internal_compile_7["close"] ?? null) : null), "html", null, true);
        echo "</button>
            </div>
          </div>
        </form-modal>
      </modal>

      <modal :is-show=\"callbackResultShow\" @close-modal=\"callbackResultShow = false\">
        <div class=\"section__title-block callback-h__title-block\">
            <h2 class=\"section__title section__title--gold\">
              ";
        // line 107
        echo twig_escape_filter($this->env, (($__internal_compile_8 = ($context["translate"] ?? null)) && is_array($__internal_compile_8) || $__internal_compile_8 instanceof ArrayAccess ? ($__internal_compile_8["thanks"] ?? null) : null), "html", null, true);
        echo "!<br>
              ";
        // line 108
        echo twig_escape_filter($this->env, (($__internal_compile_9 = ($context["translate"] ?? null)) && is_array($__internal_compile_9) || $__internal_compile_9 instanceof ArrayAccess ? ($__internal_compile_9["promise"] ?? null) : null), "html", null, true);
        echo "
            </h2>
        </div>
        <div class=\"flex\">
          <div class=\"flex__8\">
            <button 
              class=\"btn btn--gradient\" 
              @click=\"callbackResultShow = false\"
            >";
        // line 116
        echo twig_escape_filter($this->env, (($__internal_compile_10 = ($context["translate"] ?? null)) && is_array($__internal_compile_10) || $__internal_compile_10 instanceof ArrayAccess ? ($__internal_compile_10["close"] ?? null) : null), "html", null, true);
        echo "</button>
          </div>
        </div>
      </modal>

      <modal :is-show=\"airMenuShow\" @close-modal=\"airMenuShow = false\">
        ";
        // line 122
        echo twig_include($this->env, $context, "widgets/air_menu.twig");
        echo "
      </modal>
      
    </div>

  </body>

  <script src=\"";
        // line 129
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/app.min.js?v=8\"></script>

  ";
        // line 131
        echo ($context["site_scripts_in_footer"] ?? null);
        echo "

</html>
";
    }

    public function getTemplateName()
    {
        return "index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  280 => 131,  275 => 129,  265 => 122,  256 => 116,  245 => 108,  241 => 107,  229 => 98,  218 => 90,  214 => 89,  206 => 84,  202 => 83,  198 => 82,  194 => 81,  190 => 80,  183 => 76,  178 => 74,  173 => 72,  168 => 70,  163 => 68,  158 => 66,  153 => 64,  148 => 62,  143 => 60,  138 => 58,  133 => 56,  128 => 54,  123 => 52,  118 => 50,  113 => 48,  108 => 46,  103 => 44,  98 => 42,  93 => 40,  66 => 16,  58 => 11,  53 => 9,  49 => 8,  45 => 7,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "index.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/index.twig");
    }
}
