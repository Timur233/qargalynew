<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/infrastructure.twig */
class __TwigTemplate_de22f995c749ed2573626e70475bd918ec85860e2520a6ced7908d80bc04cf45 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section 
    id=\"infrastructure\" 
    data-anchor=\"infrastructure\"
    class=\"infrastructure section section--gray\"
    ref=\"infrastructure\"
>

    <div class=\"container\">
        <div class=\"section__title-block infrastructure__title\">
            <h2 class=\"section__title\">
                ";
        // line 11
        echo twig_escape_filter($this->env, ($context["infrastructure_title"] ?? null), "html", null, true);
        echo "
            </h2>
        </div>

        ";
        // line 15
        if ((($context["infrastructure_left"] ?? null) || ($context["infrastructure_right"] ?? null))) {
            // line 16
            echo "            <div class=\"flex infrastructure__content infrastructure-content\">
                <div class=\"infrastructure-content__item flex__6\">
                    ";
            // line 18
            echo ($context["infrastructure_left"] ?? null);
            echo "
                </div>
                <div class=\"infrastructure-content__item flex__6\">
                    ";
            // line 21
            echo ($context["infrastructure_right"] ?? null);
            echo "
                </div>
            </div>
        ";
        }
        // line 25
        echo "
        ";
        // line 26
        if ((twig_length_filter($this->env, ($context["infrastructure_shorts"] ?? null)) > 0)) {
            // line 27
            echo "            <div class=\"infrastructure__shorts flex infrastructure-shorts\">
                ";
            // line 28
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["infrastructure_shorts"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 29
                echo "                    <div class=\"infrastructure-shorts__item flex__4 infrastructure-short\">
                        <div class=\"infrastructure-short__title\">
                            ";
                // line 31
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_0 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 31)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0[0] ?? null) : null), "settings", [], "any", false, false, false, 31), "text", [], "any", false, false, false, 31), "html", null, true);
                echo "
                        </div>
                        <div class=\"infrastructure-short__desc\">
                            ";
                // line 34
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_1 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 34)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1[1] ?? null) : null), "settings", [], "any", false, false, false, 34), "text", [], "any", false, false, false, 34), "html", null, true);
                echo "
                        </div>
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "            </div>
        ";
        }
        // line 40
        echo "        
        <infrastructure
            :lang=\"'";
        // line 42
        echo twig_escape_filter($this->env, ($context["lang"] ?? null), "html", null, true);
        echo "'\"
            :center=\"[";
        // line 43
        echo twig_escape_filter($this->env, (($__internal_compile_2 = ($context["infrastructure_center"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2[0] ?? null) : null), "html", null, true);
        echo ", ";
        echo twig_escape_filter($this->env, (($__internal_compile_3 = ($context["infrastructure_center"] ?? null)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3[1] ?? null) : null), "html", null, true);
        echo "]\"
            :markers=\"JSON.parse(`";
        // line 44
        echo twig_escape_filter($this->env, json_encode(($context["infrastructure_markers"] ?? null), twig_constant("JSON_PRETTY_PRINT")), "html", null, true);
        echo "`)\"
        ></infrastructure>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/infrastructure.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 44,  119 => 43,  115 => 42,  111 => 40,  107 => 38,  97 => 34,  91 => 31,  87 => 29,  83 => 28,  80 => 27,  78 => 26,  75 => 25,  68 => 21,  62 => 18,  58 => 16,  56 => 15,  49 => 11,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/infrastructure.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/infrastructure.twig");
    }
}
