<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/thanks-msg.twig */
class __TwigTemplate_e0da4cd2b7a976839ae7bda0c9ba5e910c5b4c5d2684e2206fa2028a9abe51d7 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<div class=\"form_return\">
    ";
        // line 2
        if (($context["userName"] ?? null)) {
            // line 3
            echo "    <p class='mb-1'>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["translater"] ?? null), "thanks", [], "any", false, false, false, 3), "html", null, true);
            echo ", <strong>";
            echo twig_escape_filter($this->env, ($context["userName"] ?? null), "html", null, true);
            echo "</strong>!</p>
    <p>
        ";
            // line 5
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["translater"] ?? null), "promise", [], "any", false, false, false, 5), "html", null, true);
            echo "
    </p>
    ";
        } else {
            // line 8
            echo "    <p class='mb-1'><strong>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["translater"] ?? null), "thanks", [], "any", false, false, false, 8), "html", null, true);
            echo "!</strong></p>
    <p>";
            // line 9
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["translater"] ?? null), "promise", [], "any", false, false, false, 9), "html", null, true);
            echo "</p>
    <a href=\"\" class=\"mb-0 btn btn-gradient\" data-bs-dismiss=\"modal\" aria-label=\"Close\">";
            // line 10
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["translater"] ?? null), "close", [], "any", false, false, false, 10), "html", null, true);
            echo "</a>
    ";
        }
        // line 12
        echo "</div>";
    }

    public function getTemplateName()
    {
        return "widgets/thanks-msg.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 12,  65 => 10,  61 => 9,  56 => 8,  50 => 5,  42 => 3,  40 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/thanks-msg.twig", "/Applications/XAMPP/xamppfiles/htdocs/altyncity/app/views/widgets/thanks-msg.twig");
    }
}
