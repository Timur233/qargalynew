<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/footer.twig */
class __TwigTemplate_2522384715124cff535543a616ff695e21eea1d9caa339a9dfaeeef21a101b31 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<footer id=\"contacts\" data-anchor=\"contacts\" class=\"common-footer section section--primary\">

    <img 
        src=\"https://cms.abpx.kz/storage/uploads/2022/11/14/63723d05efc21contacts-img.svg\"
        class=\"section__paralax common-footer__paralax\"
        :style=\"{transform: paralaxEffect?.paralax?.about_company_two}\"
    >

    <div class=\"container\">
        <div class=\"flex\">
            <div class=\"flex__8 common-footer__map\">
                <footer-map
                    :center=\"[";
        // line 13
        echo twig_escape_filter($this->env, (($__internal_compile_0 = ($context["map_center"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0[0] ?? null) : null), "html", null, true);
        echo ", ";
        echo twig_escape_filter($this->env, (($__internal_compile_1 = ($context["map_center"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1[1] ?? null) : null), "html", null, true);
        echo "]\"
                    :polygons=\"[";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["map_polygons"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["polygon"]) {
            // line 15
            echo "                    [";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["polygon"]);
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                echo "[";
                echo twig_escape_filter($this->env, (($__internal_compile_2 = $context["item"]) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2[0] ?? null) : null), "html", null, true);
                echo ",";
                echo twig_escape_filter($this->env, (($__internal_compile_3 = $context["item"]) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3[1] ?? null) : null), "html", null, true);
                echo "],";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "],";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['polygon'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "]\"
                    :markers=\"JSON.parse(`";
        // line 16
        echo twig_escape_filter($this->env, json_encode(($context["map_markers"] ?? null), twig_constant("JSON_PRETTY_PRINT")), "html", null, true);
        echo "`)\"
                ></footer-map>
            </div>
            <div class=\"flex__4 contacts\">
                <div class=\"section__title-block\">
                    <h2 class=\"section__title section__title--gold\">";
        // line 21
        echo twig_escape_filter($this->env, (($__internal_compile_4 = ($context["translate"] ?? null)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4["contacts"] ?? null) : null), "html", null, true);
        echo "</h2>
                </div>

                <div class=\"contacts__items\">
                    <div class=\"contact-item\">
                        <img src=\"https://cms.abpx.kz/storage/uploads/2022/11/14/6372373b23cf7icon-pin.svg\" class=\"contact-item__icon\">
                        <span class=\"contact-item__label\">
                            ";
        // line 28
        echo ($context["site_adress"] ?? null);
        echo "
                        </span>
                    </div>
                    <div class=\"contact-item\">
                        <img src=\"https://cms.abpx.kz/storage/uploads/2022/11/14/6372373cd494aicon-phone.svg\" class=\"contact-item__icon\">
                        <a href=\"tel:";
        // line 33
        echo twig_escape_filter($this->env, ($context["site_phone"] ?? null), "html", null, true);
        echo "\" class=\"contact-item__label contact-item__phone\">
                            <strong>";
        // line 34
        echo twig_escape_filter($this->env, ($context["site_phone"] ?? null), "html", null, true);
        echo "</strong>
                        </a>
                    </div>
                    <div class=\"contact-item\">
                        <img src=\"https://cms.abpx.kz/storage/uploads/2022/11/14/6372373e1e72661e668600bdadGroup-24.svg\" class=\"contact-item__icon\">
                        <span class=\"contact-item__label\">
                            ";
        // line 40
        echo ($context["site_adress_two"] ?? null);
        echo "
                        </span>
                    </div>
                </div>

                <div class=\"contacts__social\">
                    ";
        // line 46
        if (($context["site_insta"] ?? null)) {
            // line 47
            echo "                        <a href=\"https://instagram.com/";
            echo twig_escape_filter($this->env, ($context["site_insta"] ?? null), "html", null, true);
            echo "\" target=\"_blank\" class=\"contacts__social-item\">
                            <img src=\"https://cms.abpx.kz/storage/uploads/2022/11/14/6372384471240icon-instagram.svg\">
                        </a>
                    ";
        }
        // line 51
        echo "                    ";
        if (($context["site_face"] ?? null)) {
            // line 52
            echo "                        <a href=\"https://facebook.com/";
            echo twig_escape_filter($this->env, ($context["site_face"] ?? null), "html", null, true);
            echo "\" target=\"_blank\" class=\"contacts__social-item\">
                            <img src=\"https://cms.abpx.kz/storage/uploads/2022/11/14/6372384351f71icon-facebook.svg\">
                        </a>
                    ";
        }
        // line 56
        echo "                </div>

                <div class=\"contacts__copyright\">
                    <p>© QrgalyCity 2023. ";
        // line 59
        echo twig_escape_filter($this->env, (($__internal_compile_5 = ($context["translate"] ?? null)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess ? ($__internal_compile_5["copyright"] ?? null) : null), "html", null, true);
        echo "</p>
                    <p>
                        ";
        // line 61
        echo twig_escape_filter($this->env, (($__internal_compile_6 = ($context["translate"] ?? null)) && is_array($__internal_compile_6) || $__internal_compile_6 instanceof ArrayAccess ? ($__internal_compile_6["footer_disclaimer"] ?? null) : null), "html", null, true);
        echo "
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>";
    }

    public function getTemplateName()
    {
        return "widgets/footer.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  161 => 61,  156 => 59,  151 => 56,  143 => 52,  140 => 51,  132 => 47,  130 => 46,  121 => 40,  112 => 34,  108 => 33,  100 => 28,  90 => 21,  82 => 16,  61 => 15,  57 => 14,  51 => 13,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/footer.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/footer.twig");
    }
}
