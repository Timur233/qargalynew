<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/filter_appartaments.twig */
class __TwigTemplate_d0764e863db532c6f21530eaa3857f41cfcd340e6969ce48ebea7971d018f0e6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"filterAppartaments\" 
    class=\"
        section 
        section--gray 
        section--crop 
        appartaments
    \"
    ref=\"appartaments\"
>
    <img 
        src=\"https://cms.abpx.kz/storage/uploads/2022/11/10/636cc20e3fe0fflats-img.svg\" 
        class=\"section__paralax appartaments__paralax\"
        :style=\"{transform: paralaxEffect?.paralax?.appartaments}\"
    >
    <div class=\"container\">
        <filter-appartaments
            :section-title=\"'Квартиры'\"
        >
            <div class=\"flats-info\">
                <div class=\"flats-info__pay-methods flats-pay\">
                    <span class=\"flats-pay__label\">Выберите условия покупки</span>
                    <ul class=\"flats-pay__list\">
                        <li class=\"flats-pay__item\" ref=\"flatsPay1\">
                            Оплата 100%
                            
                            <div class=\"flats-pay__hidden\">
                                <div class=\"section__title-block\">
                                    <h2 class=\"section__title section__title--gold\"> 
                                        Оплата 100%
                                    </h2>
                                </div>
                                <div class=\"flats-pay__content\" ref=\"flatsPayContent1\">
                                    <p>Минимальная цена за м<sup>2</sup></p>
                                    <p>Что нужно сделать?</p>
                                    <ol>
                                    <li>Приходите к нам в отдел продаж;</li>
                                    <li>Выберите квартиру мечты;</li>
                                    <li>Заключите договор;</li>
                                    <li>Внесите оплату.</li>
                                    </ol>
                                    <p>Мы экономим ваше время</p>
                                    <ul>
                                    <li>Персональный менеджер для каждого клиента</li>
                                    <li>Экскурсии по строительным объектам</li>
                                    <li>Бесплатные консультации</li>
                                    <li>Полное сопровождение сделки</li>
                                    <li>Подбор самых подходящих вариантов</li>
                                    </ul>
                                    <p>Покупайте выгодно!</p>
                                </div>
                            </div>
                        </li>
                        <li class=\"flats-pay__item\">Рассрочка</li>
                        <li class=\"flats-pay__item\">Ипотека</li>
                    </ul>
                </div>

                <div class=\"flats-info__order flats-order\">
                    <span class=\"flats-order__title\">
                        Выберите свою квартиру
                    </span>
                    <span class=\"flats-order__label\">
                        Квартиры сдаются в черновой отделке
                    </span>
                    <button 
                        class=\"btn btn--primary\"
                        @click=\"callbackModalShow = !callbackModalShow\"
                    >Отправить заявку</button>
                </div>
            </div>
        </filter-appartaments>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/filter_appartaments.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/filter_appartaments.twig", "/Applications/XAMPP/xamppfiles/htdocs/altyncity/app/views/widgets/filter_appartaments.twig");
    }
}
