<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/online-tour.twig */
class __TwigTemplate_411ebf417cee53d238f515bbadf5c75f709b642718fb77c5857ec7605391b2d7 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if (($context["online_tour"] ?? null)) {
            // line 2
            echo "    <section class=\"section section--pb online-tour\">
        <div class=\"container\">
            <div class=\"section__title-block\">
                <h2 class=\"section__title\">";
            // line 5
            echo twig_escape_filter($this->env, ($context["online_tour_title"] ?? null), "html", null, true);
            echo "</h2>
            </div>
        </div>

        <div class=\"container\">
            <iframe 
                id=\"embed-id\" 
                loading=\"lazy\" 
                class=\"ku-embed\" 
                frameborder=\"0\" 
                allowfullscreen=\"\" 
                allow=\"xr-spatial-tracking; gyroscope; accelerometer\" 
                scrolling=\"no\" 
                src=\"";
            // line 18
            echo twig_escape_filter($this->env, ($context["online_tour_link"] ?? null), "html", null, true);
            echo "\" 
                style=\"height: 700px;\"
            ></iframe>
        </div>
    </section>
";
        }
    }

    public function getTemplateName()
    {
        return "widgets/online-tour.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 18,  44 => 5,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/online-tour.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/online-tour.twig");
    }
}
