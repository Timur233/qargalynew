<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/callback.twig */
class __TwigTemplate_adef2da155a3770caba2a00e5ae3ff88ad9e6becbbe8c4a605afea6fc93a7689 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section class=\"section section--pb second-callback\">
    <div class=\"container\">
        <div class=\"second-callback__block\">
    
            <img 
                class=\"section__paralax section__paralax--primary\" 
                src=\"https://cms.abpx.kz/storage/uploads/2022/10/19/634fda74b60e6order-img-3.svg\"
            >
            <img 
                class=\"section__paralax section__paralax--second\" 
                src=\"https://cms.abpx.kz/storage/uploads/2022/10/20/63512b3579128order-img-1.svg\"
            >

            <img 
                src=\"https://cms.abpx.kz/storage/uploads/2022/12/01/638906cb2172alogo-white.svg\" 
                class=\"second-callback__logo\"
            >

            <callback-form class=\"callback-h__form second-callback__form flex__8\"
               user-name-placeholder=\"";
        // line 20
        echo twig_escape_filter($this->env, (($__internal_compile_0 = ($context["translate"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["name"] ?? null) : null), "html", null, true);
        echo "\"
               no-valid-phone-number=\"";
        // line 21
        echo twig_escape_filter($this->env, (($__internal_compile_1 = ($context["translate"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["no_valid_number"] ?? null) : null), "html", null, true);
        echo "\"
               no-valid-form-data=\"";
        // line 22
        echo twig_escape_filter($this->env, (($__internal_compile_2 = ($context["translate"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["na_valid_form"] ?? null) : null), "html", null, true);
        echo "\"
               submit-text=\"";
        // line 23
        echo twig_escape_filter($this->env, (($__internal_compile_3 = ($context["translate"] ?? null)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3["leave_order"] ?? null) : null), "html", null, true);
        echo "\"
               @show-form-result=\"callbackResultShow = true\"
            ></callback-form>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/callback.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 23,  66 => 22,  62 => 21,  58 => 20,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/callback.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/callback.twig");
    }
}
