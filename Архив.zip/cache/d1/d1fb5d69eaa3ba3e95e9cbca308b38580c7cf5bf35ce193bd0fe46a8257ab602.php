<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/commerce.twig */
class __TwigTemplate_ae995039ecc5179d8c90a36945d1253a0c8341b47c10ebe27e3fe6fb83be5a0c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if (($context["commerce"] ?? null)) {
            // line 2
            echo "<section class=\"
        commerce 
        section 
        section--primary 
        section--crop
    \"
    ref=\"commerceBlock\"
>
    
    <img 
        class=\"section__paralax section__paralax--primary\" 
        src=\"https://cms.abpx.kz/storage/uploads/2022/10/19/634fda74b60e6order-img-3.svg\"
        :style=\"{transform: paralaxEffect?.paralax?.commerce}\"
    >
    <img 
        class=\"section__paralax section__paralax--second\" 
        src=\"https://cms.abpx.kz/storage/uploads/2022/10/20/63512b3579128order-img-1.svg\"
        :style=\"{transform: paralaxEffect?.paralax?.commerce_two}\"
    >

    <div class=\"container\">
        <div class=\"flex\">
            <div class=\"flex__7 com-info\">
                <div class=\"section__title-block\">
                    <h2 class=\"section__title commerce__title section__title--gold\">
                        ";
            // line 27
            echo ($context["commerce_title"] ?? null);
            echo "
                    </h2>
                </div>
                <span class=\"com-info__label\">
                    ";
            // line 31
            echo ($context["commerce_desc"] ?? null);
            echo "
                </span>
                <div class=\"flex com-info__items\">
                    ";
            // line 34
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["commerce_facts"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["fact"]) {
                // line 35
                echo "                        <div class=\"flex__6 com-info__item\">
                            ";
                // line 36
                if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_0 = twig_get_attribute($this->env, $this->source, $context["fact"], "children", [], "any", false, false, false, 36)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0[0] ?? null) : null), "settings", [], "any", false, false, false, 36), "image", [], "any", false, false, false, 36), "path", [], "any", false, false, false, 36)) {
                    // line 37
                    echo "                                <img 
                                    src=\"https://cms.abpx.kz";
                    // line 38
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_1 = twig_get_attribute($this->env, $this->source, $context["fact"], "children", [], "any", false, false, false, 38)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1[0] ?? null) : null), "settings", [], "any", false, false, false, 38), "image", [], "any", false, false, false, 38), "path", [], "any", false, false, false, 38), "html", null, true);
                    echo "\" 
                                    alt=\"";
                    // line 39
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_2 = twig_get_attribute($this->env, $this->source, $context["fact"], "children", [], "any", false, false, false, 39)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2[1] ?? null) : null), "settings", [], "any", false, false, false, 39), "text", [], "any", false, false, false, 39), "html", null, true);
                    echo "\"
                                >
                            ";
                }
                // line 42
                echo "                            <span>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_3 = twig_get_attribute($this->env, $this->source, $context["fact"], "children", [], "any", false, false, false, 42)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3[1] ?? null) : null), "settings", [], "any", false, false, false, 42), "text", [], "any", false, false, false, 42), "html", null, true);
                echo "</span>
                        </div>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fact'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 45
            echo "                </div>
                <button 
                    class=\"btn btn--gradient com-info__button\"
                    @click=\"callbackModalShow = !callbackModalShow\"
                >
                    ";
            // line 50
            echo twig_escape_filter($this->env, (($__internal_compile_4 = ($context["translate"] ?? null)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4["consultation"] ?? null) : null), "html", null, true);
            echo "
                </button>
            </div>
            <div class=\"flex__5 com-image\">
                <div class=\"commerce__image\">
                    <img src=\"https://cms.abpx.kz";
            // line 55
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["commerce_image"] ?? null), "path", [], "any", false, false, false, 55), "html", null, true);
            echo "\" class=\"com-image__img\">
                    <span class=\"com-image__label\">";
            // line 56
            echo twig_escape_filter($this->env, ($context["commerce_label"] ?? null), "html", null, true);
            echo "</span>
                </div>
            </div>
        </div>
    </div>
</section>
";
        }
    }

    public function getTemplateName()
    {
        return "widgets/commerce.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 56,  126 => 55,  118 => 50,  111 => 45,  101 => 42,  95 => 39,  91 => 38,  88 => 37,  86 => 36,  83 => 35,  79 => 34,  73 => 31,  66 => 27,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/commerce.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/commerce.twig");
    }
}
