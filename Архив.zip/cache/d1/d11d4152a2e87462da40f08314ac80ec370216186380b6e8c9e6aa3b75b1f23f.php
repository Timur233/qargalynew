<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/benefits.twig */
class __TwigTemplate_b995803a24375ee41159b3b57e73298e9fc9473835124f0d4814173a59c4ef9e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if (($context["benefits"] ?? null)) {
            // line 2
            echo "    <section class=\"section benefits section--pb\" id=\"advantages\" data-anchor=\"advantages\">
        <div class=\"container\">
            ";
            // line 4
            if (($context["benefits_title"] ?? null)) {
                // line 5
                echo "                <div class=\"section__title-block\">
                    <h2 class=\"section__title\">";
                // line 6
                echo twig_escape_filter($this->env, ($context["benefits_title"] ?? null), "html", null, true);
                echo "</h2>
                </div>
            ";
            }
            // line 9
            echo "        </div>
        <div class=\"container\">
            <benefits-swiper :is-loop=\"false\" :menu-list=\"[";
            // line 11
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["benefits_list"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                echo "'";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_0 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 11)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0[3] ?? null) : null), "settings", [], "any", false, false, false, 11), "text", [], "any", false, false, false, 11), "html", null, true);
                echo "',";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "]\">
                ";
            // line 12
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["benefits_list"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 13
                echo "                    <swiper-slide class=\"benefits__item benefit-item flex\">
                        <div class=\"benefit-item__info flex__7\">
                            <h3 class=\"benefit-item__title\">
                                ";
                // line 16
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_1 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 16)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1[0] ?? null) : null), "settings", [], "any", false, false, false, 16), "text", [], "any", false, false, false, 16), "html", null, true);
                echo "
                            </h3>
                            ";
                // line 18
                echo twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_2 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 18)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2[1] ?? null) : null), "settings", [], "any", false, false, false, 18), "text", [], "any", false, false, false, 18);
                echo "

                            <div class=\"benefit-item__index\">
                                ";
                // line 21
                if ((twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 21) < 9)) {
                    // line 22
                    echo "                                    0";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 22), "html", null, true);
                    echo "<sub>/";
                    echo twig_escape_filter($this->env, twig_length_filter($this->env, ($context["benefits_list"] ?? null)), "html", null, true);
                    echo "</sub>
                                ";
                } else {
                    // line 24
                    echo "                                    ";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 24), "html", null, true);
                    echo "<sub>/";
                    echo twig_escape_filter($this->env, twig_length_filter($this->env, ($context["benefits_list"] ?? null)), "html", null, true);
                    echo "</sub>
                                ";
                }
                // line 26
                echo "                            </div>
                        </div>
                        <div class=\"benefit-item__image flex__5\">
                            <img 
                                src=\"https://cms.abpx.kz";
                // line 30
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_3 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 30)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3[2] ?? null) : null), "settings", [], "any", false, false, false, 30), "image", [], "any", false, false, false, 30), "path", [], "any", false, false, false, 30), "html", null, true);
                echo "\" 
                                alt=\"\"
                            >
                        </div>
                    </swiper-slide>
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 36
            echo "            </benefits-swiper>
        </div>
    </section>
";
        }
    }

    public function getTemplateName()
    {
        return "widgets/benefits.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  148 => 36,  128 => 30,  122 => 26,  114 => 24,  106 => 22,  104 => 21,  98 => 18,  93 => 16,  88 => 13,  71 => 12,  58 => 11,  54 => 9,  48 => 6,  45 => 5,  43 => 4,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/benefits.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/benefits.twig");
    }
}
