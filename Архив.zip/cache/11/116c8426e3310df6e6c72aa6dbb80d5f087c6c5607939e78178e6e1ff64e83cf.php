<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/building_steps.twig */
class __TwigTemplate_2b6f8443fc31f72ce26fc32d5020b89425ca2604a8f1f7b76034a4c952e56877 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if ((array_key_exists("building_steps", $context) &&  !twig_test_empty(($context["building_steps"] ?? null)))) {
            // line 2
            echo "    <section id=\"building-steps\" data-anchor=\"building-steps\" class=\"building-steps section\">
        <div class=\"container\">
            <div class=\"section__title-block\">
                <h2 class=\"section__title\">";
            // line 5
            echo twig_escape_filter($this->env, (($__internal_compile_0 = ($context["translate"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["building_steps"] ?? null) : null), "html", null, true);
            echo "</h2>
            </div>
        </div>
        <div class=\"container\">
            <carousel-swiper 
                class=\"building-steps__list\"
                :per-view=\"6\" 
                :is-loop=\"false\" 
                :breakpoints=\"{
                    0: {
                        slidesPerView: 1.8
                    },
                    520: {
                        slidesPerView: 3.2
                    },
                    768: {
                        slidesPerView: 4
                    },
                    1020: {
                        slidesPerView: 5
                    },
                    1200: {
                        slidesPerView: 6
                    }
                }\" 
            >
                ";
            // line 31
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["building_steps"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 32
                echo "                    <swiper-slide 
                        class=\"building-steps__item building-item\" 
                        @click=\"showLightBox(
                            ";
                // line 35
                if (twig_get_attribute($this->env, $this->source, $context["item"], "panoramas", [], "any", false, false, false, 35)) {
                    echo "'";
                    echo twig_escape_filter($this->env, (($__internal_compile_1 = twig_get_attribute($this->env, $this->source, $context["item"], "panoramas", [], "any", false, false, false, 35)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1[0] ?? null) : null), "html", null, true);
                    echo "', true";
                }
                // line 36
                echo "                            ";
                if (twig_get_attribute($this->env, $this->source, $context["item"], "gallery", [], "any", false, false, false, 36)) {
                    // line 37
                    echo "                                [";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["item"], "gallery", [], "any", false, false, false, 37));
                    foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                        echo " 
                                    'https://cms.abpx.kz";
                        // line 38
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["image"], "path", [], "any", false, false, false, 38), "html", null, true);
                        echo "', 
                                ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 39
                    echo "]
                            ";
                }
                // line 41
                echo "                        )\"
                    >
                        <span class=\"building-item__plus\">+</span>
                        <span class=\"building-item__date\">
                            ";
                // line 45
                echo twig_escape_filter($this->env, (($__internal_compile_2 = ($context["translate"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2[twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "format_date", [], "any", false, false, false, 45), "month", [], "any", false, false, false, 45)] ?? null) : null), "html", null, true);
                echo "
                            ";
                // line 46
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "format_date", [], "any", false, false, false, 46), "year", [], "any", false, false, false, 46), "html", null, true);
                echo "
                        </span>
                    </swiper-slide>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 50
            echo "            </carousel-swiper>
        </div>
    </section>
";
        }
    }

    public function getTemplateName()
    {
        return "widgets/building_steps.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 50,  120 => 46,  116 => 45,  110 => 41,  106 => 39,  98 => 38,  91 => 37,  88 => 36,  82 => 35,  77 => 32,  73 => 31,  44 => 5,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/building_steps.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/building_steps.twig");
    }
}
