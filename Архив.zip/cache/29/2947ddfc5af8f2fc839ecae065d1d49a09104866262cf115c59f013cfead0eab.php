<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/about_project.twig */
class __TwigTemplate_97e8b2ba4314e9f02ec8ff31d7082464291e357c038708a58261052434cc5f45 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"about-project\" data-anchor=\"about-project\" class=\"about-project section\" ref=\"aboutProject\">
    <img 
        src=\"https://cms.abpx.kz/storage/uploads/2022/11/08/636a05c22151adetails-img-2.svg\"
        class=\"about-project__paralax section__paralax\"
        :style=\"{transform: paralaxEffect?.paralax?.about_project}\"
    >

    <div class=\"container\">
        <div class=\"about-project__images about-images\">
            <div class=\"about-images__left\">
                <img class=\"about-images__img\" src=\"https://cms.abpx.kz";
        // line 11
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["about_image_1"] ?? null), "path", [], "any", false, false, false, 11), "html", null, true);
        echo "\">
            </div>
            <div class=\"about-images__right\">
                <img class=\"about-images__img\" src=\"https://cms.abpx.kz";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["about_image_2"] ?? null), "path", [], "any", false, false, false, 14), "html", null, true);
        echo "\">
            </div>
        </div>

        <div class=\"about-details\">
            <img 
                src=\"https://cms.abpx.kz/storage/uploads/2022/11/08/636a03f9d31d4details-img-1.svg\" 
                alt=\"\" class=\"about-details__paralax\"
            >

            <div class=\"flex about-details__list\">
                <div class=\"flex__8 about-details__left\">
                    <div class=\"flex\">
                        ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["about_list_1"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 28
            echo "                            <div class=\"flex__3 about-details__item detail-item\">
                                <span class=\"detail-item__sub-title\">
                                    ";
            // line 30
            echo twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_0 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 30)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0[0] ?? null) : null), "settings", [], "any", false, false, false, 30), "text", [], "any", false, false, false, 30);
            echo "
                                </span>
                                <span class=\"detail-item__title\">
                                    ";
            // line 33
            echo twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_1 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 33)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1[1] ?? null) : null), "settings", [], "any", false, false, false, 33), "text", [], "any", false, false, false, 33);
            echo "
                                </span>
                                <span class=\"detail-item__sub-title\">
                                    ";
            // line 36
            echo twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_2 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 36)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2[2] ?? null) : null), "settings", [], "any", false, false, false, 36), "text", [], "any", false, false, false, 36);
            echo "
                                </span>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "                    </div>
                </div>
                <div class=\"flex__4 about-details__right\">
                    <div class=\"flex\">
                        ";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["about_list_2"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 45
            echo "                            <div class=\"flex__6 about-details__item detail-item\">
                                <span class=\"detail-item__sub-title\">
                                    ";
            // line 47
            echo twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_3 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 47)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3[0] ?? null) : null), "settings", [], "any", false, false, false, 47), "text", [], "any", false, false, false, 47);
            echo "
                                </span>
                                <span class=\"detail-item__title\">
                                    ";
            // line 50
            echo twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_4 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 50)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4[1] ?? null) : null), "settings", [], "any", false, false, false, 50), "text", [], "any", false, false, false, 50);
            echo "
                                </span>
                                <span class=\"detail-item__sub-title\">
                                    ";
            // line 53
            echo twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_5 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 53)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess ? ($__internal_compile_5[2] ?? null) : null), "settings", [], "any", false, false, false, 53), "text", [], "any", false, false, false, 53);
            echo "
                                </span>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        echo "                    </div>
                </div>
            </div>
        </div>

        <div class=\"about-project__images about-images\">
            <div class=\"about-images__right\">
                <img class=\"about-images__img\" src=\"https://cms.abpx.kz";
        // line 64
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["about_image_4"] ?? null), "path", [], "any", false, false, false, 64), "html", null, true);
        echo "\">
            </div>
            <div class=\"about-images__left\">
                <img class=\"about-images__img\" src=\"https://cms.abpx.kz";
        // line 67
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["about_image_3"] ?? null), "path", [], "any", false, false, false, 67), "html", null, true);
        echo "\">
            </div>
        </div>
        
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/about_project.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  152 => 67,  146 => 64,  137 => 57,  127 => 53,  121 => 50,  115 => 47,  111 => 45,  107 => 44,  101 => 40,  91 => 36,  85 => 33,  79 => 30,  75 => 28,  71 => 27,  55 => 14,  49 => 11,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/about_project.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/about_project.twig");
    }
}
