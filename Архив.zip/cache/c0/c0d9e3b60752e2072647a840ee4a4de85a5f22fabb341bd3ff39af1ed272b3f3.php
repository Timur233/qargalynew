<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/air_menu.twig */
class __TwigTemplate_926620cf86cb56dabfc3c9cdd6608f6126317a550dbc4d33185b6c620a5b2f9e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<div class=\"air-menu air-menu__container\" @click=\"airMenuShow = false\">
    <div class=\"air-menu__list\">
        <a 
            href=\"#\" 
            class=\"air-menu__item\"
        >";
        // line 6
        echo twig_escape_filter($this->env, (($__internal_compile_0 = ($context["translate"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["main_page"] ?? null) : null), "html", null, true);
        echo "</a>
        <a 
            href=\"#about-project\" 
            class=\"air-menu__item\"
        >";
        // line 10
        echo twig_escape_filter($this->env, (($__internal_compile_1 = ($context["translate"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["about_of_project"] ?? null) : null), "html", null, true);
        echo "</a>
        <a 
            href=\"#advantages\" 
            class=\"air-menu__item\"
        >";
        // line 14
        echo twig_escape_filter($this->env, (($__internal_compile_2 = ($context["translate"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["advantages"] ?? null) : null), "html", null, true);
        echo "</a>
        <a 
            href=\"#appartaments\" 
            class=\"air-menu__item\"
        >";
        // line 18
        echo twig_escape_filter($this->env, (($__internal_compile_3 = ($context["translate"] ?? null)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3["flats"] ?? null) : null), "html", null, true);
        echo "</a>
        <a 
            href=\"#building-steps\" 
            class=\"air-menu__item\"
        >";
        // line 22
        echo twig_escape_filter($this->env, (($__internal_compile_4 = ($context["translate"] ?? null)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4["building"] ?? null) : null), "html", null, true);
        echo "</a>
        <a 
            href=\"#about-company\" 
            class=\"air-menu__item\"
        >";
        // line 26
        echo twig_escape_filter($this->env, (($__internal_compile_5 = ($context["translate"] ?? null)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess ? ($__internal_compile_5["about_of_company"] ?? null) : null), "html", null, true);
        echo "</a>
        <a 
            href=\"#contacts\" 
            class=\"air-menu__item\"
        >";
        // line 30
        echo twig_escape_filter($this->env, (($__internal_compile_6 = ($context["translate"] ?? null)) && is_array($__internal_compile_6) || $__internal_compile_6 instanceof ArrayAccess ? ($__internal_compile_6["contacts"] ?? null) : null), "html", null, true);
        echo "</a>
    </div>

    <a href=\"#appartaments\" class=\"btn btn--gradient\">
        ";
        // line 34
        echo twig_escape_filter($this->env, (($__internal_compile_7 = ($context["translate"] ?? null)) && is_array($__internal_compile_7) || $__internal_compile_7 instanceof ArrayAccess ? ($__internal_compile_7["select_flat"] ?? null) : null), "html", null, true);
        echo "
    </a>
</div>";
    }

    public function getTemplateName()
    {
        return "widgets/air_menu.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 34,  86 => 30,  79 => 26,  72 => 22,  65 => 18,  58 => 14,  51 => 10,  44 => 6,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/air_menu.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/air_menu.twig");
    }
}
