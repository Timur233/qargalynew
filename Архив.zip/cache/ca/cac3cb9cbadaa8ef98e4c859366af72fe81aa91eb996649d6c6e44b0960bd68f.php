<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/appartaments.twig */
class __TwigTemplate_a51e81722f2cda7ab4df16fc0e35efee98ca60d6e6f4f896f9bba915b6ae8812 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"appartaments\" 
    data-anchor=\"appartaments\"
    class=\"
        section 
        section--gray 
        section--crop 
        appartaments
    \"
    ref=\"appartaments\"
>
    <img 
        src=\"https://cms.abpx.kz/storage/uploads/2022/11/10/636cc20e3fe0fflats-img.svg\" 
        class=\"section__paralax appartaments__paralax\"
        :style=\"{transform: paralaxEffect?.paralax?.appartaments}\"
    >
    <div class=\"container\">
        <appartaments
            title=\"";
        // line 18
        echo twig_escape_filter($this->env, ($context["flats_title"] ?? null), "html", null, true);
        echo "\"
            room-item=\"";
        // line 19
        echo twig_escape_filter($this->env, (($__internal_compile_0 = ($context["translate"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["room_item"] ?? null) : null), "html", null, true);
        echo "\"
            rooms-cap=\"";
        // line 20
        echo twig_escape_filter($this->env, (($__internal_compile_1 = ($context["translate"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["rooms"] ?? null) : null), "html", null, true);
        echo "\"
            square-cap=\"";
        // line 21
        echo twig_escape_filter($this->env, (($__internal_compile_2 = ($context["translate"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["square"] ?? null) : null), "html", null, true);
        echo "\"
        >
            <div class=\"flats-call\">
                <div class=\"flats-call pay-info\">
                    <h2 class=\"pay-info__title\">";
        // line 25
        echo twig_escape_filter($this->env, ($context["flats_terms_title"] ?? null), "html", null, true);
        echo "</h2>
                    <ul class=\"pay-info__items\">
                        ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["flats_terms"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 28
            echo "                            <li class=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "settings", [], "any", false, false, false, 28), "id", [], "any", false, false, false, 28), "html", null, true);
            echo "\" @click=\"payInfoId = '";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "settings", [], "any", false, false, false, 28), "id", [], "any", false, false, false, 28), "html", null, true);
            echo "'; payInfoShow = true;\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_3 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 28)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3[0] ?? null) : null), "settings", [], "any", false, false, false, 28), "text", [], "any", false, false, false, 28), "html", null, true);
            echo "</li>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "                    </ul>
                </div>
                <button 
                    class=\"btn btn--gradient\" 
                    @click=\"callbackModalShow = !callbackModalShow\"
                >";
        // line 35
        echo twig_escape_filter($this->env, (($__internal_compile_4 = ($context["translate"] ?? null)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4["leave_order"] ?? null) : null), "html", null, true);
        echo "</button>
            </div>
        </appartaments>
    </div>
</section>

";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["flats_terms"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 42
            echo "    <modal :is-show=\"payInfoShow && payInfoId === '";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "settings", [], "any", false, false, false, 42), "id", [], "any", false, false, false, 42), "html", null, true);
            echo "'\" @close-modal=\"payInfoShow = false\">
        <div class=\"pay-info__modal\">
            <div class=\"section__title-block\">
                <h2 class=\"section__title section__title--gold\">
                    ";
            // line 46
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_5 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 46)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess ? ($__internal_compile_5[0] ?? null) : null), "settings", [], "any", false, false, false, 46), "text", [], "any", false, false, false, 46), "html", null, true);
            echo "
                </h2>
            </div>
            <div class=\"pay-info__content\">
                ";
            // line 50
            echo twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_6 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 50)) && is_array($__internal_compile_6) || $__internal_compile_6 instanceof ArrayAccess ? ($__internal_compile_6[1] ?? null) : null), "settings", [], "any", false, false, false, 50), "text", [], "any", false, false, false, 50);
            echo "
            </div>
        </div>
    </modal>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "widgets/appartaments.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  132 => 50,  125 => 46,  117 => 42,  113 => 41,  104 => 35,  97 => 30,  84 => 28,  80 => 27,  75 => 25,  68 => 21,  64 => 20,  60 => 19,  56 => 18,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/appartaments.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/appartaments.twig");
    }
}
