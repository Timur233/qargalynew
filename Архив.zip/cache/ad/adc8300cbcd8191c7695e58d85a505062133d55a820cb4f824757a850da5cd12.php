<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/_header.twig */
class __TwigTemplate_9c3e91833de1d2a4e662706ab64a384f271c2617e941c4641beb2b979fa1fb68 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<header class=\"main-header\" :class=\"{'main-header--sticky': headerIsSticky}\">
   <div class=\"container-fluid\">
      <div class=\"main-header__content\">
         <div class=\"main-header__menu-toggle\" @click=\"airMenuShow = !airMenuShow\">
            <div class=\"menu-toggle header-toggle\" :class=\"{ 'menu-toggle--open': airMenuShow }\">
               <span class=\"menu-toggle__line\"></span>
               <span class=\"menu-toggle__line\"></span>
               <span class=\"menu-toggle__line\"></span>
            </div>
         </div>

         <div class=\"logo-block main-header__logo\">
            <a href=\"";
        // line 13
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "\">
               <img 
                  src=\"https://cms.abpx.kz";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["site_second_logo"] ?? null), "path", [], "any", false, false, false, 15), "html", null, true);
        echo "\" 
                  class=\"logo-block__img\" 
                  alt=\"Exclusive Qurylys\"
               >
               <img 
                  src=\"https://cms.abpx.kz";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["site_logo"] ?? null), "path", [], "any", false, false, false, 20), "html", null, true);
        echo "\" 
                  class=\"logo-block__img logo-block__img--dark\" 
                  alt=\"Exclusive Qurylys\"
               >
            </a>
         </div>

         <div class=\"navigate main-header__navigate\">
            <nav class=\"navigate__block\">
               <a href=\"#home\" class=\"navigate__link\">";
        // line 29
        echo twig_escape_filter($this->env, (($__internal_compile_0 = ($context["translate"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["main_page"] ?? null) : null), "html", null, true);
        echo "</a>
               <a href=\"#about-project\" class=\"navigate__link\">";
        // line 30
        echo twig_escape_filter($this->env, (($__internal_compile_1 = ($context["translate"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["about_of_project"] ?? null) : null), "html", null, true);
        echo "</a>
               <a href=\"#advantages\" class=\"navigate__link\">";
        // line 31
        echo twig_escape_filter($this->env, (($__internal_compile_2 = ($context["translate"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["advantages"] ?? null) : null), "html", null, true);
        echo "</a>
               <a href=\"#appartaments\" class=\"navigate__link\">";
        // line 32
        echo twig_escape_filter($this->env, (($__internal_compile_3 = ($context["translate"] ?? null)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3["flats"] ?? null) : null), "html", null, true);
        echo "</a>
               <a href=\"#building-steps\" class=\"navigate__link\">";
        // line 33
        echo twig_escape_filter($this->env, (($__internal_compile_4 = ($context["translate"] ?? null)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4["building"] ?? null) : null), "html", null, true);
        echo "</a>
               <a href=\"#about-company\" class=\"navigate__link\">";
        // line 34
        echo twig_escape_filter($this->env, (($__internal_compile_5 = ($context["translate"] ?? null)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess ? ($__internal_compile_5["about_of_company"] ?? null) : null), "html", null, true);
        echo "</a>
               <a href=\"#contacts\" class=\"navigate__link\">";
        // line 35
        echo twig_escape_filter($this->env, (($__internal_compile_6 = ($context["translate"] ?? null)) && is_array($__internal_compile_6) || $__internal_compile_6 instanceof ArrayAccess ? ($__internal_compile_6["contacts"] ?? null) : null), "html", null, true);
        echo "</a>
            </nav>
         </div>
         
         <div class=\"main-contact main-header__contact\">
            <div class=\"main-contact__lang-switcher lang-switcher\">
               ";
        // line 41
        if ((($context["lang"] ?? null) == "kk")) {
            // line 42
            echo "                  <a href=\"";
            echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
            echo "\" class=\"lang-switcher__link\">RU</a>
               ";
        } else {
            // line 44
            echo "                  <a href=\"";
            echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
            echo "kk\" class=\"lang-switcher__link\">KZ</a>
               ";
        }
        // line 46
        echo "            </div>

            <div class=\"main-contact__block\">

               <a href=\"tel:";
        // line 50
        echo twig_escape_filter($this->env, ($context["site_phone"] ?? null), "html", null, true);
        echo "\" onclick=\"\" class=\"main-contact__phone\">
                  <img class=\"desctop\" src=\"https://cms.abpx.kz/storage/uploads/2022/12/01/6388830b4cf1cicon-phone-1-1.svg\" >
                  <img 
                     src=\"https://cms.abpx.kz/storage/uploads/2022/12/01/6388830b4cf1cicon-phone-1-1.svg\" 
                     class=\"mobile\" 
                     alt=\"";
        // line 55
        echo twig_escape_filter($this->env, (($__internal_compile_7 = ($context["translate"] ?? null)) && is_array($__internal_compile_7) || $__internal_compile_7 instanceof ArrayAccess ? ($__internal_compile_7["leave"] ?? null) : null), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (($__internal_compile_8 = ($context["translate"] ?? null)) && is_array($__internal_compile_8) || $__internal_compile_8 instanceof ArrayAccess ? ($__internal_compile_8["application"] ?? null) : null), "html", null, true);
        echo "\"
                  >
                  <span>";
        // line 57
        echo twig_escape_filter($this->env, ($context["site_phone"] ?? null), "html", null, true);
        echo "</span>
               </a>

               <button 
                  class=\"main-contact__callback-link callback-link\"
                  @click=\"callbackModalShow = !callbackModalShow\"
               >
                  <span class=\"callback-link__text\">
                     ";
        // line 65
        echo twig_escape_filter($this->env, (($__internal_compile_9 = ($context["translate"] ?? null)) && is_array($__internal_compile_9) || $__internal_compile_9 instanceof ArrayAccess ? ($__internal_compile_9["leave"] ?? null) : null), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (($__internal_compile_10 = ($context["translate"] ?? null)) && is_array($__internal_compile_10) || $__internal_compile_10 instanceof ArrayAccess ? ($__internal_compile_10["application"] ?? null) : null), "html", null, true);
        echo " 
                  </span>
                  <img 
                     src=\"https://cms.abpx.kz/storage/uploads/2022/12/01/6388830b4cf1cicon-phone-1-1.svg\" 
                     class=\"callback-link__icon\" 
                     alt=\"";
        // line 70
        echo twig_escape_filter($this->env, (($__internal_compile_11 = ($context["translate"] ?? null)) && is_array($__internal_compile_11) || $__internal_compile_11 instanceof ArrayAccess ? ($__internal_compile_11["leave"] ?? null) : null), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (($__internal_compile_12 = ($context["translate"] ?? null)) && is_array($__internal_compile_12) || $__internal_compile_12 instanceof ArrayAccess ? ($__internal_compile_12["application"] ?? null) : null), "html", null, true);
        echo "\"
                  >
               </button>

               <a href=\"tel:";
        // line 74
        echo twig_escape_filter($this->env, ($context["site_phone"] ?? null), "html", null, true);
        echo "\" class=\"main-contact__mobile\">
                  <img src=\"";
        // line 75
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/img/icons/phone.svg\" alt=\"\">
               </a>

            </div>

         </div>
      </div>
   </div>
</header>";
    }

    public function getTemplateName()
    {
        return "widgets/_header.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  178 => 75,  174 => 74,  165 => 70,  155 => 65,  144 => 57,  137 => 55,  129 => 50,  123 => 46,  117 => 44,  111 => 42,  109 => 41,  100 => 35,  96 => 34,  92 => 33,  88 => 32,  84 => 31,  80 => 30,  76 => 29,  64 => 20,  56 => 15,  51 => 13,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/_header.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/_header.twig");
    }
}
