<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/carousel.twig */
class __TwigTemplate_4c267d424bb959f2738e686e80001f4b3dda4495953e2545c198d44708d2d787 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if ((($context["carousel_enable"] ?? null) && (twig_length_filter($this->env, ($context["carousel_items"] ?? null)) > 0))) {
            // line 2
            echo "    <section class=\"section section carousel\">
        <div class=\"container\">
            ";
            // line 4
            if (($context["carousel_title"] ?? null)) {
                // line 5
                echo "                <div class=\"section__title-block\">
                    <h2 class=\"section__title\">";
                // line 6
                echo twig_escape_filter($this->env, ($context["carousel_title"] ?? null), "html", null, true);
                echo "</h2>
                </div>
            ";
            }
            // line 9
            echo "        </div>
        <div class=\"container\">
            <carousel-swiper 
                :per-view=\"2.7\" 
                :is-loop=\"false\" 
                class=\"carousel-items\"
            >
                ";
            // line 16
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["carousel_items"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 17
                echo "                    <swiper-slide 
                        class=\"carousel-items__one\" 
                        @click=\"showLightBox(
                            ['https://cms.abpx.kz";
                // line 20
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "path", [], "any", false, false, false, 20), "html", null, true);
                echo "']
                        )\"
                    >
                        <img 
                            data-src=\"https://cms.abpx.kz";
                // line 24
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "path", [], "any", false, false, false, 24), "html", null, true);
                echo "\" 
                            class=\"carousel-items__img swiper-lazy\"
                            alt=\"";
                // line 26
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "meta", [], "any", false, false, false, 26), "title", [], "any", false, false, false, 26), "html", null, true);
                echo "\"
                        >
                        <div class=\"swiper-lazy-preloader\"></div>
                    </swiper-slide>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 31
            echo "            </carousel-swiper>
        </div>
    </section>
";
        }
    }

    public function getTemplateName()
    {
        return "widgets/carousel.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 31,  84 => 26,  79 => 24,  72 => 20,  67 => 17,  63 => 16,  54 => 9,  48 => 6,  45 => 5,  43 => 4,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/carousel.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/carousel.twig");
    }
}
