<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/contacts.twig */
class __TwigTemplate_ad2f102512a1d5321ac0a8b8bd83715ebf2841d97f40ada4f2d4caa9b18e8dda extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"contacts\" class=\"section contacts\">
  <div class=\"container\">
    <div class=\"flex contacts__flex\">
      <div class=\"flex__4 contacts__info contacts-info\">
        <div class=\"contacts__group contact-group\">
          <h4 class=\"contact-group__title\">
            Телефон:
          </h4>
          <a href=\"tel:";
        // line 9
        echo twig_escape_filter($this->env, ($context["site_phone"] ?? null), "html", null, true);
        echo "\" class=\"contact-group__value contact-group__value--phone\">
            ";
        // line 10
        echo twig_escape_filter($this->env, ($context["site_phone"] ?? null), "html", null, true);
        echo "
          </a>
        </div>
        <div class=\"contacts__group contact-group\">
          <h4 class=\"contact-group__title\">
            ОТДЕЛ ПРОДАЖ:
          </h4>
          <span class=\"contact-group__value contact-group__value--adres\">
            <img src=\"assets/img/adres-icon1.svg\" alt=\"\">
            ";
        // line 19
        echo twig_escape_filter($this->env, ($context["site_adress"] ?? null), "html", null, true);
        echo "
          </span>
        </div>
        <div class=\"contacts__group contact-group\">
          <h4 class=\"contact-group__title\">
            ЦЕНТРАЛЬНЫЙ ОТДЕЛ ПРОДАЖ:
          </h4>
          <span class=\"contact-group__value contact-group__value--adres\">
            <img src=\"assets/img/adres-icon2.svg\" alt=\"\">
            ";
        // line 28
        echo twig_escape_filter($this->env, ($context["site_adress_two"] ?? null), "html", null, true);
        echo "
          </span>
        </div>
      </div>
      <div class=\"flex__8 contacts__map\">
        <div id=\"contacts-map\" class=\"contacts-map\">
        </div>
        <span class=\"contacts__author-label author-label\">
          ";
        // line 36
        echo twig_escape_filter($this->env, ($context["about_label"] ?? null), "html", null, true);
        echo "
        </span>
      </div>
    </div>
  </div>

  <div class=\"lines\">
    <div class=\"lines__wrapper container\">
        <span class=\"lines__line lines__line--black lines__line--1\"></span>
        <span class=\"lines__line lines__line--black lines__line--2\"></span>
        <span class=\"lines__line lines__line--black lines__line--3\"></span>
        <span class=\"lines__line lines__line--black lines__line--2\"></span>
        <span class=\"lines__line lines__line--black lines__line--1\"></span>
    </div>
</div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/contacts.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 36,  75 => 28,  63 => 19,  51 => 10,  47 => 9,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/contacts.twig", "/Applications/XAMPP/xamppfiles/htdocs/altyncity/app/views/widgets/contacts.twig");
    }
}
