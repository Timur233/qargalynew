<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/advantages.twig */
class __TwigTemplate_69ce5dd797f73b626913f6ac1cfcf18e0845c217eea9eed4df7649ad12f7956d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"advantages\" class=\"advantages section\">
    <div class=\"container\">
        <div class=\"advantages__swiper swiper-container\">
            <div class=\"swiper-wrapper advantages__wrapper\">
                ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["advantages_items"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 6
            echo "                    <div 
                        class=\"swiper-slide advantages__slide\" 
                        style=\"background-image: 
                            url('https://cms.abpx.kz";
            // line 9
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_0 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 9)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0[2] ?? null) : null), "settings", [], "any", false, false, false, 9), "image", [], "any", false, false, false, 9), "path", [], "any", false, false, false, 9), "html", null, true);
            echo "')\"
                    >
                        <h3 class=\"advantages__title\">";
            // line 11
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_1 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 11)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1[0] ?? null) : null), "settings", [], "any", false, false, false, 11), "text", [], "any", false, false, false, 11), "html", null, true);
            echo "</h3>
                        <div class=\"advantages__body\">
                            ";
            // line 13
            echo twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_2 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 13)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2[1] ?? null) : null), "settings", [], "any", false, false, false, 13), "text", [], "any", false, false, false, 13);
            echo "
                        </div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "            </div>
        </div>
    </div>

    <div class=\"lines\">
        <div class=\"lines__wrapper container\">
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--3\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/advantages.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 17,  62 => 13,  57 => 11,  52 => 9,  47 => 6,  43 => 5,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/advantages.twig", "/Applications/XAMPP/xamppfiles/htdocs/altyncity/app/views/widgets/advantages.twig");
    }
}
