<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/about_company.twig */
class __TwigTemplate_3cf5201a553229b4b321957dbcd9d223f242913ab7a2841fdb6205762b4f599c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section 
    id=\"about-company\" 
    data-anchor=\"about-company\"
    class=\"about-company section section--gradient\"
    ref=\"aboutCompany\"
>

    <img 
        style=\"display: none;\"
        src=\"https://cms.abpx.kz/storage/uploads/2022/11/14/6372306eb3b53about-img-1.svg\"
        class=\"section__paralax about-company__paralax\"
        :style=\"{transform: paralaxEffect?.paralax?.about_company}\"
    >

    <img 
        src=\"https://cms.abpx.kz/storage/uploads/2022/11/10/636cc20e3fe0fflats-img.svg\"
        class=\"section__paralax about-company__paralax about-company__paralax--two\"
        :style=\"{transform: paralaxEffect?.paralax?.about_company_two}\"
    >

    <div class=\"container\">
        <div class=\"about-company__block flex\">
            <div class=\"flex__9\">
                <div class=\"company-info\">
                    <div class=\"flex\">
                        <div class=\"flex__4 company-info__logo\">
                            <img 
                                src=\"https://cms.abpx.kz/storage/uploads/2022/02/09/620411381e38861c9645a93a2blogo-bold-1.svg\"
                                class=\"company-info__logo-img\"
                            >
                            <a 
                                href=\"https://exin.kz/\" 
                                target=\"_blank\" 
                                class=\"company-info__link\"
                            >Exin.kz</a>
                        </div>
                        <div class=\"flex__8 company-info__text company-text\">
                            <h3 class=\"company-text__title\">
                                ";
        // line 39
        echo twig_escape_filter($this->env, ($context["company_title"] ?? null), "html", null, true);
        echo "
                            </h3>
                            ";
        // line 41
        echo ($context["company_about"] ?? null);
        echo "
                        </div>
                    </div>
                </div>
            </div>
            <div class=\"flex__3\">
                <div class=\"company-items\">
                    <img 
                        class=\"section__paralax company-items__paralax\" 
                        src=\"https://cms.abpx.kz/storage/uploads/2022/10/20/63512b3579128order-img-1.svg\" 
                    >

                    ";
        // line 53
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["company_items"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 54
            echo "                        <div class=\"company-items__point\">
                            <div class=\"company-items__number\">
                                ";
            // line 56
            echo twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_0 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 56)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0[0] ?? null) : null), "settings", [], "any", false, false, false, 56), "text", [], "any", false, false, false, 56);
            echo "
                            </div>
                            <span class=\"company-items__label\">
                                ";
            // line 59
            echo twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (($__internal_compile_1 = twig_get_attribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 59)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1[1] ?? null) : null), "settings", [], "any", false, false, false, 59), "text", [], "any", false, false, false, 59);
            echo "
                            </span>
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 63
        echo "                    
                </div>
            </div>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/about_company.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 63,  111 => 59,  105 => 56,  101 => 54,  97 => 53,  82 => 41,  77 => 39,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/about_company.twig", "/Applications/XAMPP/xamppfiles/htdocs/qargalynew/app/views/widgets/about_company.twig");
    }
}
